/// <reference path="globals/jquery/jquery.d.ts" />
/// <reference path="globals/jquery/jqueryui.d.ts" />
